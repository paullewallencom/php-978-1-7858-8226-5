<?php
namespace books\V1\Rpc\All;

use Zend\Mvc\Controller\AbstractActionController;

class AllController extends AbstractActionController
{
    public function allAction()
    {
    }
}
