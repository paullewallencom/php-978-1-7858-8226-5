<?php
/**
 * Created by PhpStorm.
 * User: altafhussain
 * Date: 1/19/16
 * Time: 3:32 PM
 */

namespace publishers\packt;

const KEY = '123FHSUIOP67F';
const COUNT = 10;
const URL = 'https://www.packtpub.com/';