The code folder has two sub folders
1) minify
2) grunt

1) minify has the php code and libraries to minify js and css using php. Just copy and past this folder to the root of a webserver and execute it in browser like http://yoururl.com/minify

2) The grunt folder has the package.json and GruntFile files. That codes can be olny executed if node.js, npm and grunt are installed. 