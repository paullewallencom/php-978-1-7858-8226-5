<?php
require __DIR__ . '/src/books/Module.php';